<!DOCTYPE html>
<html lang="en">


  <head>
    <title>Assessment of Prior Learning Confirmation</title>
    <link type="text/css" rel="stylesheet" href="APLStyle.css">
    <link type="text/javascript" href="APL.js">

  </head>



  <body>

    <div>
      <h1>Ferris State University </h1>
      <h2>Assessment of Prior Learning</h2>
    </div>

    <div>
    <p>
      First Name: <?php echo $_GET["firstName"];?> <br>
      Last Name: <?php echo $_GET["lastName"];?><br>
      Transfering: <?php echo $_GET["transfer"]; ?><br>
      Veteran: <?php echo $_GET["veteran"]; ?><br>
    </div>
    <br>
    <div>
      <h3> Communications Competency</h3>
      Your entry:
      <?php echo $_GET["commEntry"];?>
    </div>
    <div>
      <h3> Quantitative Literacy</h3>
      Your entry:
      <?php echo $_GET["quantEntry"];?>
    </div>
    <div>
      <h3>Natural Sciences</h3>
      Your entry:
      <?php echo $_GET["natSci"];?>
    </div>
    <div>
      <h3>Cultural Competency</h3>
      Your entry:
      <?php echo $_GET["culture"];?>
    </div>
    <div>
      <h3>Self & Society</h3>
      Your entry:
      <?php echo $_GET["selfSoc"];?>
    </div>

    <div>
      <h3>Diversity</h3>
      Your entry:
      <?php echo $_GET["diversity"];?>
    </div>

    <div>
      <h3>Collaboration</h3>
      Your entry:
      <?php echo $_GET["collab"];?>
    </div>

    <div>
      <h3>Problem Solving</h3>
      Your entry:
      <?php echo $_GET["probSolve"];?>
    </div>
      <p><strong>Please confirm your submission.</strong></p>

      <form>

        <input type="checkbox" name="consent" value="Yes"> I agree to submit the above information
        for evaluation by an academic advisor at Ferris State University. I understand that this
        information will be shared only with parties directly involved in facilitating my potential
        enrollment at Ferris State University and will not be shared with any third-parties.
        </form>
<br>
    <div class="horizontalButton">

      <button onclick="goBack();">Edit My Submission</button>
      <button onclick="validateContinue();">Save and Submit</button>

      <script>
        function goBack() {
          window.history.back();
        }

         function validateContinue() {
           alert ("Your Assessment of Prior Learning has been submitted!");
           window.location.href = "thankYou.html";
         }

      </script>
  </body>
</html>
