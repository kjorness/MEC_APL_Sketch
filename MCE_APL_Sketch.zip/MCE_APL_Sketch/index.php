<!DOCTYPE html>
<html lang="en">


<html>
  <head>
    <title>Opening Page/Index</title>
    <link type="text/css" rel="stylesheet" href="APLStyle.css">
    <link type="text/javascript" href="APL.js">

  </head>

  <body onload="checkAuth();">

    <div>
      <h1>Ferris State University<h1>
      <h2>Assessment of Prior Learning<h2>
    </div>

    <div>
      <p><strong> Welcome to Ferris State University's Online Assessment of
        Prior Learning</strong></p>
        <p>Ferris State University is dedicated to promoting opportunity for
          members of our community. Everyday Ferris faculty and staff strive to
          provide students with the tools they need to create the lives they want,
          no matter their background</p>
    </div>
      <p>The experiences and training that you have had outside of college
        may count towards credit at Ferris State University.</p>

        <p>An Assessment of Prior Learning (APL) is a review of your experiences
        and training as related to you future academic career. Ferris' Online APL
      gives you the opportunity to see what credits may be available to you and
      share this information with a Ferris advisor</p><br>
      <p><strong>Click below to begin your Assessment of Prior Learning.</strong></p><br>
    <div>
      <button onclick="location.href='APLForm.html';">Assess My Learning</button>
    </div>

    <script type="text/javascript">
      var attemptCount = 0;
      function checkAuth() {
      userPin = prompt ("Please enter the password");


      if (userPin == "mcetest1") {
          alert ("Great! Please note, this is only a demo site. Be sure to take notes on what can be better:)");
        }

      else {
        alert ("sorry, that is not correct");
        attemptCount ++;
        checkAuth();
        }


      }


    </script>

  </body>
</html>







</body>
